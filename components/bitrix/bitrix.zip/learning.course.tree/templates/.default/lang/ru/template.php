<?
$MESS['LEARNING_AVAILABLE_SINCE'] = "доступно с #DATE#";
?>