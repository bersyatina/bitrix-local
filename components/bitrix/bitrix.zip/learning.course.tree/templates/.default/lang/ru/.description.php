<?
$MESS ['LEARN_TREE_DEFAULT_NAME'] = "Шаблон по умолчанию в виде дерева";
$MESS ['LEARN_TREE_DEFAULT_DESC'] = "Шаблон по умолчанию в виде дерева";
?>