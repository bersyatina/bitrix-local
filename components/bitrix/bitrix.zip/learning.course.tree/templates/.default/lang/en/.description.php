<?
$MESS ['LEARN_TREE_DEFAULT_NAME'] = "Tree-like default template";
$MESS ['LEARN_TREE_DEFAULT_DESC'] = "Tree-like default template";
?>