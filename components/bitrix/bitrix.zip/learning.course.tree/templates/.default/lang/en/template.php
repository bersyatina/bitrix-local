<?
$MESS["LEARNING_AVAILABLE_SINCE"] = "available since #DATE#";
?>