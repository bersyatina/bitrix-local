<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arTemplateDescription = array(
	"NAME" => GetMessage("LEARN_NAVIGATION_NAME"),
	"DESCRIPTION" => GetMessage("LEARN_NAVIGATION_DESC"),
);
?>