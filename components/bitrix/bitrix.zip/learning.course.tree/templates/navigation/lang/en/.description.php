<?
$MESS ['LEARN_NAVIGATION_NAME'] = "Navigation template";
$MESS ['LEARN_NAVIGATION_DESC'] = "Navigation template";
?>