<?
$MESS["LEARNING_START_COURSE"] = "Start the course";
?>