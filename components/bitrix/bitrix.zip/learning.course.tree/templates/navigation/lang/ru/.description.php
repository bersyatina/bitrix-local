<?
$MESS ['LEARN_NAVIGATION_NAME'] = "Шаблон навигационной цепочки";
$MESS ['LEARN_NAVIGATION_DESC'] = "Шаблон навигационной цепочки";
?>