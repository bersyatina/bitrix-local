<?
$MESS["LEARNING_START_COURSE"] = "Начать курс обучения";
?>