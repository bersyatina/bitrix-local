<?
$MESS ['LEARNING_COURSE_TREE_NAME'] = "Дерево курса";
$MESS ['LEARNING_COURSE_TREE_DESC'] = "Выводит иерархию глав и уроков";
$MESS ['LEARNING_SERVICE'] = "Обучение";
$MESS ['LEARNING_COURSE_SERVICE'] = "Курсы";
?>