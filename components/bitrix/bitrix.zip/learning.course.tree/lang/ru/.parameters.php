<?
$MESS['LEARNING_DESC_YES'] = "Да";
$MESS['LEARNING_DESC_NO'] = "Нет";
$MESS['LEARNING_COURSE_ID_NAME'] = "Идентификатор курса";
$MESS['LEARNING_CHECK_PERMISSIONS'] = "Проверять право доступа";
$MESS['LEARNING_SELF_TEST_TEMPLATE_NAME'] = "URL, ведущий на страницу с самотестированием";
$MESS['LEARNING_CHAPTER_DETAIL_TEMPLATE_NAME'] = "URL, ведущий на страницу с главой";
$MESS['LEARNING_LESSON_DETAIL_TEMPLATE_NAME'] = "URL, ведущий на страницу с уроком";
$MESS['LEARNING_COURSE_DETAIL_TEMPLATE_NAME'] = "URL, ведущий на страницу с детальным просмотром курса";
$MESS['LEARNING_TESTS_LIST_TEMPLATE_NAME'] = "URL, ведущий на страницу со списком тестов";
$MESS['LEARNING_TEST_DETAIL_TEMPLATE_NAME'] = "URL, ведущий на страницу прохождения теста";
$MESS['LEARNING_URL_TEMPLATE_GROUP'] = "Управление адресами страниц";
?>