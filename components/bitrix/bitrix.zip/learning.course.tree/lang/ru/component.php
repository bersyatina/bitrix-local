<?
$MESS ['LEARNING_MODULE_NOT_FOUND'] = "Модуль обучения не установлен.";
$MESS ['LEARNING_COURSE_DENIED'] = "Курс не найден или доступ к нему запрещен.";
$MESS ['LEARNING_COURSE_DESCRIPTION'] = "Описание курса";
$MESS ['LEARNING_TEST_LIST'] = "Тесты";
?>