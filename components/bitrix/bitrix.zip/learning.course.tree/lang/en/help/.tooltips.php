<?
$MESS ['COURSE_ID_TIP'] = "Select here one of the existing courses. If you select <b><i>(other)</i></b>, you will have to specify the course ID in the field beside.";
$MESS ['COURSE_DETAIL_TEMPLATE_TIP'] = "The path to a course details page.";
$MESS ['CHAPTER_DETAIL_TEMPLATE_TIP'] = "The path to a course chapter page.";
$MESS ['LESSON_DETAIL_TEMPLATE_TIP'] = "The path to a course lesson page.";
$MESS ['SELF_TEST_TEMPLATE_TIP'] = "The path to a self-check test page.";
$MESS ['TESTS_LIST_TEMPLATE_TIP'] = "The path to a page displaying all tests of the course.";
$MESS ['TEST_DETAIL_TEMPLATE_TIP'] = "The path to the main test page.";
$MESS ['CHECK_PERMISSIONS_TIP'] = "Select here \"Yes\" if you want to check the user access permissions for the course.";
$MESS ['SET_TITLE_TIP'] = "Checking this option will set the page title to the course chapter name.";
?>
