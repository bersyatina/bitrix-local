<?
$MESS ['LEARNING_COURSE_TREE_NAME'] = "Course tree";
$MESS ['LEARNING_COURSE_TREE_DESC'] = "Displays hierarchical structure for chapters and lessons";
$MESS ['LEARNING_SERVICE'] = "e-Learning";
$MESS ['LEARNING_COURSE_SERVICE'] = "Courses";
?>