<?
$MESS ['LEARNING_MODULE_NOT_FOUND'] = "e-Learning module is not installed.";
$MESS ['LEARNING_COURSE_DENIED'] = "Course not found or access denied.";
$MESS ['LEARNING_COURSE_DESCRIPTION'] = "Course description";
$MESS ['LEARNING_TEST_LIST'] = "Tests";
?>