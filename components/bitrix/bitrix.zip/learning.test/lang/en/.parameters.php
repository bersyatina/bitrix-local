<?
$MESS ['T_LEARNING_DETAIL_ID'] = "Test ID";
$MESS ['LEARNING_DESC_YES'] = "Yes";
$MESS ['LEARNING_DESC_NO'] = "No";
$MESS ['LEARNING_CHECK_PERMISSIONS'] = "Check allowed permissions";
$MESS ['LEARNING_GRADEBOOK_TEMPLATE_NAME'] = "Test results page URL";
$MESS ['LEARNING_PAGE_WINDOW_NAME'] = "Number of questions in navigation";
$MESS ['LEARNING_SHOW_TIME_LIMIT'] = "Show time counter";
$MESS ['T_LEARNING_PAGE_NUMBER_VARIABLE'] = "Question ID";
$MESS ['LEARNING_COURSE_ID'] = "Course ID";
?>