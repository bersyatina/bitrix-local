<?
$MESS ['COURSE_ID_TIP'] = "Select here one of the existing courses. If you select <b><i>(other)</i></b>, you will have to specify the course ID in the field beside.";
$MESS ['TEST_ID_TIP'] = "Select here one of the existing tests. If you select <b><i>(other)</i></b>, you will have to specify the test ID in the field beside.";
$MESS ['PAGE_NUMBER_VARIABLE_TIP'] = "The name of a variable for the test question ID.";
$MESS ['GRADEBOOK_TEMPLATE_TIP'] = "The path to a page containing the test result (i.e. the gradebook).";
$MESS ['PAGE_WINDOW_TIP'] = "Number of questions to display in the navigation chain.";
$MESS ['SHOW_TIME_LIMIT_TIP'] = "If a test imposes a time restriction, enabling this option will show the time counter.";
$MESS ['SET_TITLE_TIP'] = "Checking this option will set the page title to the user name.";
?>
