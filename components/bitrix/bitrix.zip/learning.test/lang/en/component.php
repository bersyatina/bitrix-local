<?
$MESS["LEARNING_MODULE_NOT_FOUND"] = "e-Learning module is not installed.";
$MESS["LEARNING_TEST_DENIED"] = "Test not found or access denied.";
$MESS["LEARNING_NO_AUTHORIZE"] = "Authorization required to view this page.";
$MESS["LEARNING_LIMIT_ERROR"] = "No more attempts.";
$MESS["LEARNING_TIME_LIMIT"] = "Test pass time expired.";
$MESS["LEARNING_ATTEMPT_CREATE_ERROR"] = "An error occurred when trying to create task.";
$MESS["LEARNING_ATTEMPT_NOT_FOUND_ERROR"] = "Task was not found.";
$MESS["LEARNING_RESPONSE_SAVE_ERROR"] = "An error occurred when trying to save answer.";
$MESS["LEARNING_COURSES_TEST_EDIT"] = "Edit test";
$MESS["LEARNING_COURSES_QUESTION_EDIT"] = "Edit question";
$MESS["LEARNING_TEST_DENIED_PREVIOUS"] = "You have to pass the test #TEST_LINK# successfully to gain access to this test.";
$MESS["LEARNING_COURSES_TEST_DELETE"] = "Delete Test";
$MESS["LEARNING_COURSES_TEST_DELETE_CONF"] = "This will delete all the information related to this test! Continue?";
$MESS["LEARNING_ATTEMPT_FAILED"] = "Test failed";
$MESS["LEARNING_TEST_TIME_INTERVAL_ERROR"] = "You can take the test again in ";
$MESS["LEARNING_TEST_TIME_INTERVAL_ERROR_D"] = "d.";
$MESS["LEARNING_TEST_TIME_INTERVAL_ERROR_H"] = "hr.";
$MESS["LEARNING_TEST_TIME_INTERVAL_ERROR_M"] = "min.";
$MESS["LEARNING_NEW_TEXT_ANSWER"] = "New Text Answer";
?>