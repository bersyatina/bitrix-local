<?
$MESS["LEARNING_MODULE_NOT_FOUND"] = "Модуль обучения не установлен.";
$MESS["LEARNING_TEST_DENIED"] = "Тест не найден или доступ к нему запрещен.";
$MESS["LEARNING_NO_AUTHORIZE"] = "Для просмотра этой страницы вы должны быть авторизованы.";
$MESS["LEARNING_LIMIT_ERROR"] = "Превышен лимит попыток.";
$MESS["LEARNING_TIME_LIMIT"] = "Время прохождения теста истекло.";
$MESS["LEARNING_ATTEMPT_CREATE_ERROR"] = "Ошибка при попытке создания задания.";
$MESS["LEARNING_ATTEMPT_NOT_FOUND_ERROR"] = "Попытка не найдена.";
$MESS["LEARNING_RESPONSE_SAVE_ERROR"] = "Ошибка при попытке сохранения ответа.";
$MESS["LEARNING_COURSES_TEST_EDIT"] = "Изменить тест";
$MESS["LEARNING_COURSES_QUESTION_EDIT"] = "Изменить вопрос";
$MESS["LEARNING_COURSES_TEST_DELETE"] = "Удалить тест";
$MESS["LEARNING_COURSES_TEST_DELETE_CONF"] = "Будет удалена вся информация, связанная с этой записью! Продолжить?";
$MESS["LEARNING_ATTEMPT_FAILED"] = "Тест не пройден";
$MESS["LEARNING_TEST_DENIED_PREVIOUS"] = "Доступ к тесту запрещен, так как вы не прошли тест #TEST_LINK#";
$MESS["LEARNING_TEST_TIME_INTERVAL_ERROR"] = "Повторно сдать тест вы сможете через";
$MESS["LEARNING_TEST_TIME_INTERVAL_ERROR_D"] = "д.";
$MESS["LEARNING_TEST_TIME_INTERVAL_ERROR_H"] = "ч.";
$MESS["LEARNING_TEST_TIME_INTERVAL_ERROR_M"] = "мин.";
$MESS["LEARNING_NEW_TEXT_ANSWER"] = "Новый текстовый ответ";
?>