<?
$MESS ['LEARNING_TEST_DETAIL_NAME'] = "Контрольный тест";
$MESS ['LEARNING_TEST_DETAIL_DESC'] = "Контрольный тест";
$MESS ['LEARNING_SERVICE'] = "Обучение";
$MESS ['LEARNING_TEST_SERVICE'] = "Тесты";
?>