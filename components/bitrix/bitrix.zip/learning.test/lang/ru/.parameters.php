<?
$MESS ['T_LEARNING_DETAIL_ID'] = "Идентификатор теста";
$MESS ['LEARNING_DESC_YES'] = "Да";
$MESS ['LEARNING_DESC_NO'] = "Нет";
$MESS ['LEARNING_CHECK_PERMISSIONS'] = "Проверять право доступа";
$MESS ['LEARNING_GRADEBOOK_TEMPLATE_NAME'] = "URL, ведущий на страницу с результатами тестирования";
$MESS ['LEARNING_PAGE_WINDOW_NAME'] = "Количество вопросов в навигационной цепочке";
$MESS ['T_LEARNING_PAGE_NUMBER_VARIABLE'] = "Идентификатор вопроса";
$MESS ['LEARNING_SHOW_TIME_LIMIT'] = "Показывать счетчик ограничения времени";
$MESS ['LEARNING_COURSE_ID'] = "Идентификатор курса";
?>