<?
$MESS ['SEARCH_LABEL'] = "Find:";
?>