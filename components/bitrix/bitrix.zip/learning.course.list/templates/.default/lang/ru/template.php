<?
$MESS ['SEARCH_LABEL'] = "Найти:";
?>