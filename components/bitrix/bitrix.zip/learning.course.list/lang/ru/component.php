<?
$MESS ['LEARNING_MODULE_NOT_FOUND'] = "Модуль обучения не установлен.";
$MESS ['LEARNING_COURSE_LIST'] = "Список курсов";
$MESS ['LEARNING_COURSES_NAV'] = "Курсы";
$MESS ['LEARNING_COURSES_COURSE_ADD'] = "Добавить курс";
$MESS ['LEARNING_PANEL_CONTROL_PANEL'] = "Панель управления";
$MESS ['LEARNING_PANEL_CONTROL_PANEL_ALT'] = "Перейти в панель управления";
$MESS ['comp_course_list_toolbar_add'] = "Добавить курс";
$MESS ['comp_course_list_toolbar_add_title'] = "Добавить новый курс в панели управления";
$MESS ['comp_course_list_toolbar_list'] = "Управление курсами";
$MESS ['comp_course_list_toolbar_list_title'] = "Список курсов в панели управления";
?>