<?
$MESS ['LEARNING_DESC_ASC'] = "По возрастанию";
$MESS ['LEARNING_DESC_DESC'] = "По убыванию";
$MESS ['LEARNING_DESC_YES'] = "Да";
$MESS ['LEARNING_DESC_NO'] = "Нет";
$MESS ['LEARNING_DESC_FID'] = "Идентификатор курса";
$MESS ['LEARNING_DESC_FNAME'] = "Название";
$MESS ['LEARNING_DESC_FACT'] = "Дата начала активности";
$MESS ['LEARNING_DESC_FSORT'] = "Индекс сортировки";
$MESS ['LEARNING_DESC_FTSAMP'] = "Дата последнего изменения";
$MESS ['LEARNING_DESC_SORTBY'] = "Поле для сортировки";
$MESS ['LEARNING_DESC_SORTORDER'] = "Направление для сортировки";
$MESS ['LEARNING_COURSE_URL_NAME'] = "URL, ведущий на страницу с детальным просмотром курса";
$MESS ['LEARNING_CHECK_PERMISSIONS'] = "Проверять право доступа";
$MESS ['LEARNING_COURSES_PER_PAGE'] = "Количество курсов на странице";
?>