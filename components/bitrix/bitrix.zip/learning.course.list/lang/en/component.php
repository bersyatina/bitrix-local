<?
$MESS ['LEARNING_MODULE_NOT_FOUND'] = "e-Learning module is not installed.";
$MESS ['LEARNING_COURSE_LIST'] = "Course list";
$MESS ['LEARNING_COURSES_NAV'] = "Courses";
$MESS ['LEARNING_COURSES_COURSE_ADD'] = "Add a new course";
$MESS ['LEARNING_PANEL_CONTROL_PANEL'] = "Control Panel";
$MESS ['LEARNING_PANEL_CONTROL_PANEL_ALT'] = "Perform action in Control Panel";
$MESS ['comp_course_list_toolbar_add'] = "Add a new course";
$MESS ['comp_course_list_toolbar_add_title'] = "Add a new course in Control Panel";
$MESS ['comp_course_list_toolbar_list'] = "Course Management";
$MESS ['comp_course_list_toolbar_list_title'] = "Course List in Control Panel";
?>