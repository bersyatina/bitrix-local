<?
$MESS ['SORBY_TIP'] = "Specifies the field by which the courses will be sorted.";
$MESS ['SORORDER_TIP'] = "Specifies the order in which the courses will be sorted.";
$MESS ['COURSE_DETAIL_TEMPLATE_TIP'] = "The path to a course details page.";
$MESS ['CHECK_PERMISSIONS_TIP'] = "Select here \"Yes\" if you want to check access permissions.";
$MESS ['COURSES_PER_PAGE_TIP'] = "Maximum number of courses that can be displayed on a page. Other courses will be available via the breadcrumb navigation links.";
$MESS ['SET_TITLE_TIP'] = "Check this option to set the page title to <b>Courses</b>.";
?>
