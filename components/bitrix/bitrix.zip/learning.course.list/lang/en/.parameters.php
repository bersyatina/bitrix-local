<?
$MESS ['LEARNING_DESC_ASC'] = "Ascending";
$MESS ['LEARNING_DESC_DESC'] = "Descending";
$MESS ['LEARNING_DESC_YES'] = "Yes";
$MESS ['LEARNING_DESC_NO'] = "No";
$MESS ['LEARNING_DESC_FID'] = "Course ID";
$MESS ['LEARNING_DESC_FNAME'] = "Name";
$MESS ['LEARNING_DESC_FACT'] = "Activation date";
$MESS ['LEARNING_DESC_FSORT'] = "Sorting index";
$MESS ['LEARNING_DESC_FTSAMP'] = "Last update";
$MESS ['LEARNING_DESC_SORTBY'] = "Sorting field";
$MESS ['LEARNING_DESC_SORTORDER'] = "Sort order";
$MESS ['LEARNING_COURSE_URL_NAME'] = "Course detail page URL";
$MESS ['LEARNING_CHECK_PERMISSIONS'] = "Check allowed permissions";
$MESS ['LEARNING_COURSES_PER_PAGE'] = "Number of courses per page";
?>