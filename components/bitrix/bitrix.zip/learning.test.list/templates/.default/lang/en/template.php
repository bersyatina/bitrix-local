<?
$MESS["LEARNING_BTN_START"] = "Start";
$MESS["LEARNING_BTN_CONTINUE"] = "Continue";
$MESS["LEARNING_TEST_NAME"] = "Test name";
$MESS["LEARNING_TEST_ATTEMPT_LIMIT"] = "Attempts allowed";
$MESS["LEARNING_TEST_ATTEMPT_UNLIMITED"] = "unlimited number";
$MESS["LEARNING_TEST_TIME_LIMIT"] = "Time limit";
$MESS["LEARNING_TEST_TIME_LIMIT_UNLIMITED"] = "no limit";
$MESS["LEARNING_TEST_TIME_LIMIT_MIN"] = "min.";
$MESS["LEARNING_PASSAGE_TYPE"] = "Type of passing the test";
$MESS["LEARNING_PASSAGE_NO_FOLLOW_NO_EDIT"] = "not allowed to go to the next question without answering the current one. <b>Not allowed</b> to modify answers.";
$MESS["LEARNING_PASSAGE_FOLLOW_NO_EDIT"] = "allowed to go to the next question without answering the current one. <b>Not allowed</b> to modify answers.";
$MESS["LEARNING_PASSAGE_FOLLOW_EDIT"] = "allowed to go to the next question without answering the current one. <b>Allowed</b> to modify answers.";
$MESS["LEARNING_PREV_TEST_REQUIRED"] = "To access this test, you have to pass the test #TEST_LINK# getting at least #TEST_SCORE#% of maximum total mark.";
?>