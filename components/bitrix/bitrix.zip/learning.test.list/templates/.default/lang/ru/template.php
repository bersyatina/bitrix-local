<?
$MESS["LEARNING_BTN_START"] = "Начать";
$MESS["LEARNING_BTN_CONTINUE"] = "Продолжить";
$MESS["LEARNING_TEST_NAME"] = "Название теста";
$MESS["LEARNING_TEST_ATTEMPT_LIMIT"] = "Количество попыток";
$MESS["LEARNING_TEST_ATTEMPT_UNLIMITED"] = "неограниченное количество";
$MESS["LEARNING_TEST_TIME_LIMIT"] = "Ограничение времени";
$MESS["LEARNING_TEST_TIME_LIMIT_UNLIMITED"] = "без ограничения";
$MESS["LEARNING_TEST_TIME_LIMIT_MIN"] = "мин.";
$MESS["LEARNING_PASSAGE_TYPE"] = "Тип прохождения теста";
$MESS["LEARNING_PASSAGE_NO_FOLLOW_NO_EDIT"] = "запрещен переход к следующему вопросу без ответа на текущий вопрос, <b>нельзя</b> изменять свои ответы.";
$MESS["LEARNING_PASSAGE_FOLLOW_NO_EDIT"] = "разрешен переход к следующему вопросу без ответа на текущий вопрос, <b>нельзя</b> изменять свои ответы.";
$MESS["LEARNING_PASSAGE_FOLLOW_EDIT"] = "разрешен переход к следующему вопросу без ответа на текущий вопрос, <b>можно</b> изменять свои ответы.";
$MESS["LEARNING_PREV_TEST_REQUIRED"] = "Для доступа к тесту необходимо пройти тест #TEST_LINK# не менее чем на #TEST_SCORE#% от общего количества баллов.";
?>