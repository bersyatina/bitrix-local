<?
$MESS ['LEARNING_TEST_LIST_NAME'] = "Список тестов";
$MESS ['LEARNING_TEST_LIST_DESC'] = "Список активных тестов курса";
$MESS ['LEARNING_SERVICE'] = "Обучение";
$MESS ['LEARNING_TEST_SERVICE'] = "Тесты";
?>