<?
$MESS ['LEARNING_MODULE_NOT_FOUND'] = "Модуль обучения не установлен.";
$MESS ['LEARNING_BAD_TEST_LIST'] = 'В данном курсе сертификация не предусмотрена.';
$MESS ['LEARNING_TESTS_LIST'] = "Список тестов";
$MESS ['LEARNING_TESTS_NAV'] = "Тесты";
$MESS["LEARNING_TEST_DENIED_PREVIOUS"] = "Доступ к тесту запрещен, так как вы не прошли тест #TEST_LINK#";
$MESS['LEARNING_COURSE_DENIED']="Курс не найден или доступ к нему запрещен";
?>