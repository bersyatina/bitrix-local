<?
$MESS ['LEARNING_COURSE_ID'] = "Идентификатор курса";
$MESS ['LEARNING_DESC_YES'] = "Да";
$MESS ['LEARNING_DESC_NO'] = "Нет";
$MESS ['LEARNING_CHECK_PERMISSIONS'] = "Проверять право доступа";
$MESS ['LEARNING_TESTS_PER_PAGE'] = "Количество тестов на странице";
$MESS ['LEARNING_TEST_TEMPLATE_NAME'] = "URL, ведущий на страницу прохождения теста";
?>