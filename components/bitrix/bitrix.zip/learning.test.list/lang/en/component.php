<?
$MESS["LEARNING_MODULE_NOT_FOUND"] = "e-Learning module is not installed.";
$MESS["LEARNING_TESTS_LIST"] = "Tests list";
$MESS["LEARNING_TESTS_NAV"] = "Tests";
$MESS["LEARNING_TEST_DENIED_PREVIOUS"] = "You have to pass the test #TEST_LINK# successfully to gain access to this test.";
$MESS["LEARNING_BAD_TEST_LIST"] = "This course doesn't provide certification.";
$MESS['LEARNING_COURSE_DENIED']="Course not found or access denied.";
?>