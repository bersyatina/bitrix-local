<?
$MESS ['LEARNING_TEST_LIST_NAME'] = "Test list";
$MESS ['LEARNING_TEST_LIST_DESC'] = "List of active tests for the course";
$MESS ['LEARNING_SERVICE'] = "e-Learning";
$MESS ['LEARNING_TEST_SERVICE'] = "Tests";
?>