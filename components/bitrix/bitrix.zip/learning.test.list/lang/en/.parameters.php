<?
$MESS ['LEARNING_COURSE_ID'] = "Course ID";
$MESS ['LEARNING_DESC_YES'] = "Yes";
$MESS ['LEARNING_DESC_NO'] = "No";
$MESS ['LEARNING_CHECK_PERMISSIONS'] = "Check allowed permissions";
$MESS ['LEARNING_TESTS_PER_PAGE'] = "Number of tests per page";
$MESS ['LEARNING_TEST_TEMPLATE_NAME'] = "URL to the online test page";
?>