<?
$MESS["COURSE_ID_TIP"] = "Select here one of the existing courses. If you select <b><i>(other)</i></b>, you will have to specify the course ID in the field beside.";
$MESS["TEST_DETAIL_TEMPLATE_TIP"] = "The path to the main test page.";
$MESS["CHECK_PERMISSIONS_TIP"] = "Select here \"Yes\" if you want to check access permissions.";
$MESS["TESTS_PER_PAGE_TIP"] = "Maximum number of tests that can be displayed on a page. Other tests will be available using the breadcrumb navigation.";
$MESS["SET_TITLE_TIP"] = "Checking this option will set the page title to <b>Tests</b>.";
?>