<?
$MESS ['LEARNING_STUDENT_GRADEBOOK_NAME'] = "Student's gradebook";
$MESS ['LEARNING_STUDENT_GRADEBOOK_DESC'] = "Results of tests";
$MESS ['LEARNING_SERVICE'] = "e-Learning";
$MESS ['LEARNING_STUDENT_SERVICE'] = "Student";
?>