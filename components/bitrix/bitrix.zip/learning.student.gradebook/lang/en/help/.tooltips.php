<?
$MESS ['TEST_DETAIL_TEMPLATE_TIP'] = "The path to the main test page.";
$MESS ['COURSE_DETAIL_TEMPLATE_TIP'] = "The path to a course details page.";
$MESS ['TEST_ID_VARIABLE_TIP'] = "The name of a variable to which the test ID will be passed.";
$MESS ['SET_TITLE_TIP'] = "Checking this option will set the page title to <b>Test Result</b>.";
?>
