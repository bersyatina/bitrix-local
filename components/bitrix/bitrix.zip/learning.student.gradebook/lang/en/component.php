<?
$MESS ['LEARNING_MODULE_NOT_FOUND'] = "e-Learning module is not installed.";
$MESS ['LEARNING_NO_AUTHORIZE'] = "Authorization required to view this page.";
$MESS ['LEARNING_PROFILE_TITLE'] = "Test results";
?>