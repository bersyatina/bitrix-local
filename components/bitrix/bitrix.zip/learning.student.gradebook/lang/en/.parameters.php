<?
$MESS ['LEARNING_TEST_DETAIL_URL_NAME'] = "URL to the online test page";
$MESS ['LEARNING_COURSE_DETAIL_URL_NAME'] = "Course detail page URL";
$MESS ['LEARNING_TEST_ID_VARIABLE_NAME'] = "Test ID";
?>