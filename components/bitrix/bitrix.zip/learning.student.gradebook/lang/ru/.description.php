<?
$MESS ['LEARNING_STUDENT_GRADEBOOK_NAME'] = "Журнал студента";
$MESS ['LEARNING_STUDENT_GRADEBOOK_DESC'] = "Результаты прохождения тестов";
$MESS ['LEARNING_SERVICE'] = "Обучение";
$MESS ['LEARNING_STUDENT_SERVICE'] = "Студент";
?>