<?
$MESS ['LEARNING_TEST_DETAIL_URL_NAME'] = "URL, ведущий на страницу прохождения теста";
$MESS ['LEARNING_COURSE_DETAIL_URL_NAME'] = "URL, ведущий на страницу с детальным просмотром курса";
$MESS ['LEARNING_TEST_ID_VARIABLE_NAME'] = "Идентификатор теста";
?>