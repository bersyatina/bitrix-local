<?
$MESS ['LEARNING_MODULE_NOT_FOUND'] = "Модуль обучения не установлен.";
$MESS ['LEARNING_NO_AUTHORIZE'] = "Для просмотра этой страницы вы должны быть авторизованы.";
$MESS ['LEARNING_PROFILE_TITLE'] = "Результаты тестирования";
?>