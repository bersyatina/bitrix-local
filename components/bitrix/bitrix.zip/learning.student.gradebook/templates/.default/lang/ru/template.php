<?
$MESS["LEARNING_PROFILE_COURSE"] = "Курс";
$MESS["LEARNING_PROFILE_TEST"] = "Тест";
$MESS["LEARNING_PROFILE_SCORE"] = "Баллов";
$MESS["LEARNING_PROFILE_RESULT"] = "Пройден";
$MESS["LEARNING_PROFILE_ATTEMPTS"] = "Попыток";
$MESS["LEARNING_PROFILE_ACTION"] = "Действия";
$MESS["LEARNING_PROFILE_YES"] = "Да";
$MESS["LEARNING_PROFILE_NO"] = "Нет";
$MESS["LEARNING_PROFILE_TRY"] = "Пройти еще раз";
$MESS["LEARNING_PROFILE_NO_DATA"] = "Нет данных";
$MESS["LEARNING_PROFILE_TEST_DETAIL"] = "Список попыток";
$MESS["LEARNING_PROFILE_DATE_END"] = "Дата сдачи";
$MESS["LEARNING_PROFILE_TIME_DURATION"] = "Затраченное время";
$MESS["LEARNING_PROFILE_QUESTIONS"] = "Вопросов";
$MESS["LEARNING_BACK_TO_GRADEBOOK"] = "Вернуться на список тестов";
$MESS["LEARNING_ATTEMPT_NOT_FINISHED"] = "Попытка не закончена";
$MESS["LEARNING_ATTEMPTS_TITLE"] = "Попытки";
$MESS["LEARNING_PROFILE_MARK"] = "Оценка";
$MESS["LEARNING_PROFILE_BEST_SCORE"] = 'Лучший результат';
$MESS['LEARNING_PROFILE_LAST_SCORE'] = 'Результат последнего тестирования';
$MESS['LEARNING_PROFILE_LAST_RESULT'] = 'Последний тест пройден';
$MESS['LEARNING_TEST_CHECKED_MANUALLY_SO_NOT_ALL_RESULTS_CAN_BE_ACTUAL'] = 'Тест проверяется вручную и может быть еще не проверенным.';
?>