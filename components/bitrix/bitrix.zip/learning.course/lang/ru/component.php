<?
$MESS ['LEARNING_MODULE_NOT_FOUND'] = "Модуль обучения не установлен.";
$MESS ['LEARNING_COURSE_DENIED'] = "Курс не найден или доступ к нему запрещен.";
$MESS ['LEARNING_COURSES_COURSE_ADD'] = "Добавить курс";
$MESS ['LEARNING_COURSES_COURSE_EDIT'] = "Изменить курс";
$MESS ['LEARNING_COURSES_LESSON_ADD'] = "Добавить урок";
$MESS ['LEARNING_COURSES_LESSON_EDIT'] = "Изменить урок";
$MESS ['LEARNING_COURSES_CHAPTER_ADD'] = "Добавить главу";
$MESS ['LEARNING_COURSES_CHAPTER_EDIT'] = "Изменить главу";
$MESS ['LEARNING_COURSES_TEST_ADD'] = "Добавить тест";
$MESS ['LEARNING_COURSES_TEST_EDIT'] = "Изменить тест";
$MESS ['LEARNING_COURSES_QUEST_S_ADD'] = "Добавить вопрос (одиночный выбор)";
$MESS ['LEARNING_COURSES_QUEST_M_ADD'] = "Добавить вопрос (множественный выбор)";
$MESS ['LEARNING_COURSES_QUEST_R_ADD'] = "Добавить вопрос (сортировка)";
$MESS ['LEARNING_COURSES_QUEST_T_ADD'] = "Добавить вопрос (текстовый ответ)";
$MESS ['LEARNING_COURSE_DETAIL'] = "Курс детально";
$MESS ['LEARNING_PANEL_CONTROL_PANEL'] = "Панель управления";
$MESS ['LEARNING_PANEL_CONTROL_PANEL_ALT'] = "Перейти в панель управления";
$MESS['INCORRECT_QUESTION_MESSAGE'] = "Ошибка";
?>