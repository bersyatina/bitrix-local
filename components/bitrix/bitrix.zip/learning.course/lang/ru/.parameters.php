<?
$MESS ['LEARNING_DESC_YES'] = "Да";
$MESS ['LEARNING_DESC_NO'] = "Нет";
$MESS ['LEARNING_COURSE_ID_NAME'] = "Идентификатор курса";
$MESS ['LEARNING_CHECK_PERMISSIONS'] = "Проверять право доступа";



$MESS ['LEARN_COURSE_ID_DESC'] = "Идентификатор курса";
$MESS ['LEARN_INDEX_ID_DESC'] = "Идентификатор индексной страницы";
$MESS ['LEARN_LESSON_ID_DESC'] = "Идентификатор урока";
$MESS ['LEARN_CHAPTER_ID_DESC'] = "Идентификатор главы";
$MESS ['LEARN_SELF_TEST_DESC'] = "Идентификатор теста для самопроверки";
$MESS ['LEARN_TEST_ID_DESC'] = "Идентификатор теста";
$MESS ['LEARN_TYPE_ID_DESC'] = "Идентификатор всех материалов курса";
$MESS ['LEARN_TEST_LIST_ID_DESC'] = "Идентификатор списка тестов";
$MESS ['LEARN_GRADEBOOK_ID_DESC'] = "Идентификатор журнала";
$MESS ['LEARN_FOR_TEST_ID_DESC'] = "Идентификатор теста в журнале";


$MESS ['LEARN_INDEX_DESC'] = "URL, ведущий на главную страницу";
$MESS ['LEARN_LESSON_DETAIL_DESC'] = "URL, ведущий на страницу урока";
$MESS ['LEARN_CHAPTER_DETAIL_DESC'] = "URL, ведущий на страницу главы";
$MESS ['LEARN_TEST_SELF_DESC'] = "URL, ведущий на страницу теста для самопроверки";
$MESS ['LEARN_TEST_DETAIL_DESC'] = "URL, ведущий на страницу теста";
$MESS ['LEARN_TEST_LIST_DESC'] = "URL, ведущий на страницу списка тестов";
$MESS ['LEARN_COURSE_CONTENTS_DESC'] = "URL, ведущий на страницу со всеми материалами курса";
$MESS ['LEARN_GRADEBOOK_DESC'] = "URL, ведущий на страницу журнала";
$MESS ['LEARN_PATH_TO_USER_PROFILE'] = "URL, ведущий на страницу с профилем пользователя";

$MESS ['LEARNING_PAGE_WINDOW_NAME'] = "Количество вопросов в навигационной цепочке";
$MESS ['LEARNING_SHOW_TIME_LIMIT'] = "Показывать счетчик ограничения времени";
$MESS ['LEARNING_TESTS_PER_PAGE'] = "Количество тестов на странице";

$MESS ['TEST_DETAIL_GROUP'] = "Настройки теста";
$MESS ['TEST_LIST_GROUP'] = "Настройки списка тестов";


$MESS ['T_LEARNING_PAGE_NUMBER_VARIABLE'] = "Идентификатор вопроса";
?>