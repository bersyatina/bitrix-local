<?
$MESS["SEF_MODE_TIP"] = "Включить поддержку ЧПУ";
$MESS["COURSE_ID_TIP"] = "Идентификатор курса";
$MESS["CHECK_PERMISSIONS_TIP"] = "Проверять право доступа";
$MESS["PAGE_WINDOW_TIP"] = "Количество вопросов в навигационной цепочке";
$MESS["SHOW_TIME_LIMIT_TIP"] = "Показывать счетчик ограничения времени";
$MESS["PAGE_NUMBER_VARIABLE_TIP"] = "Идентификатор вопроса";
$MESS["TESTS_PER_PAGE_TIP"] = "Количество тестов на странице";
$MESS["SET_TITLE_TIP"] = "Устанавливать заголовок страницы";
$MESS["CACHE_TYPE_TIP"] = "Тип кеширования";
$MESS["CACHE_TIME_TIP"] = "Время кеширования (сек.)";
$MESS["VARIABLE_ALIASES_COURSE_ID_TIP"] = "Идентификатор курса";
$MESS["VARIABLE_ALIASES_INDEX_TIP"] = "Идентификатор индексной страницы";
$MESS["VARIABLE_ALIASES_LESSON_ID_TIP"] = "Идентификатор урока";
$MESS["VARIABLE_ALIASES_CHAPTER_ID_TIP"] = "Идентификатор главы";
$MESS["VARIABLE_ALIASES_SELF_TEST_ID_TIP"] = "Идентификатор теста для самопроверки";
$MESS["VARIABLE_ALIASES_TEST_ID_TIP"] = "Идентификатор теста";
$MESS["VARIABLE_ALIASES_TYPE_TIP"] = "Идентификатор всех материалов курса";
$MESS["VARIABLE_ALIASES_TEST_LIST_TIP"] = "Идентификатор списка тестов";
$MESS["VARIABLE_ALIASES_GRADEBOOK_TIP"] = "Идентификатор журнала";
$MESS["VARIABLE_ALIASES_FOR_TEST_ID_TIP"] = "Идентификатор теста в журнале";
$MESS["SEF_FOLDER_TIP"] = "Каталог ЧПУ (относительно корня сайта)";
$MESS["SEF_URL_TEMPLATES_test_TIP"] = "URL, ведущий на страницу теста";
$MESS["SEF_URL_TEMPLATES_gradebook_TIP"] = "URL, ведущий на страницу журнала";
?>