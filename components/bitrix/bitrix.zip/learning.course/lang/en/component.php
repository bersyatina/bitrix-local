<?
$MESS["LEARNING_MODULE_NOT_FOUND"] = "e-Learning module is not installed.";
$MESS["LEARNING_COURSE_DENIED"] = "Course not found or access denied.";
$MESS["LEARNING_COURSES_COURSE_ADD"] = "Add a new course";
$MESS["LEARNING_COURSES_COURSE_EDIT"] = "Edit course";
$MESS["LEARNING_COURSES_LESSON_ADD"] = "Add a new lesson";
$MESS["LEARNING_COURSES_LESSON_EDIT"] = "Edit lesson";
$MESS["LEARNING_COURSES_CHAPTER_ADD"] = "Add a new chapter";
$MESS["LEARNING_COURSES_CHAPTER_EDIT"] = "Edit chapter";
$MESS["LEARNING_COURSES_TEST_ADD"] = "Add a new test";
$MESS["LEARNING_COURSES_TEST_EDIT"] = "Edit test";
$MESS["LEARNING_COURSES_QUEST_S_ADD"] = "Add a new question (single choice)";
$MESS["LEARNING_COURSES_QUEST_M_ADD"] = "Add a new question (multiple choice)";
$MESS["LEARNING_COURSES_QUEST_R_ADD"] = "Add a new question (sort)";
$MESS["LEARNING_COURSES_QUEST_T_ADD"] = "Add a new question (text answer)";
$MESS["LEARNING_COURSE_DETAIL"] = "Course details";
$MESS["LEARNING_PANEL_CONTROL_PANEL"] = "Control Panel";
$MESS["LEARNING_PANEL_CONTROL_PANEL_ALT"] = "Perform action in Control Panel";
$MESS["INCORRECT_QUESTION_MESSAGE"] = "Error";
?>